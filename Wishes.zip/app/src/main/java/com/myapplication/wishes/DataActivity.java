package com.myapplication.wishes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DataActivity extends AppCompatActivity {

    public static MyAdapter adapter;
    public static List<History> histories;
    int num=0;
    int done=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        histories=new ArrayList<History>();
        ((TextView)findViewById(R.id.tvall)).setVisibility(View.VISIBLE);
        adapter =new MyAdapter(histories);

        try {
            adddata();
        } catch (IOException e) {
            e.printStackTrace();
        }
        final ListView listv=(ListView) findViewById(R.id.listv);
        listv.setAdapter(adapter);
    }


    private void adddata() throws IOException {
        num=0;done=0;
        histories.clear();
        DBManager.getDBManager().queryAll("  ");
        adapter.notifyDataSetChanged();

        num=histories.size();
        for(int i=0;i<histories.size();i++){
            if(histories.get(i).getTimesall()<=histories.get(i).getTimes())done++;
        }

        ((TextView)findViewById(R.id.tvall)).setText("已完成心愿"+done+"个，占比"+(100*done/num)+"%\n"+"未完成心愿"+(num-done)+"个，占比"+(100-100*done/num)+"%");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//菜单创建，没啥用
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if(id==R.id.add){
            startActivity(new Intent().setClass(DataActivity.this,Edit.class));


        }
        return super.onOptionsItemSelected(item);
    }



    public  class MyAdapter extends BaseAdapter {
        private List<History> infos;
        private LayoutInflater inflater;

        public MyAdapter(List<History> infos) {
            super();
            this.infos = infos;
            inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return infos.size();
        }

        @Override
        public Object getItem(int position) {

            return infos.get(position);
        }

        @Override
        public long getItemId(int position) {

            return 0;
        }

        // "顾客名称","商品编号","顾客地址","数量","价格"};
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            num++;

            View view = inflater.inflate(R.layout.item, null);
            TextView tv_number = (TextView) view.findViewById(R.id.textView);
            History info = infos.get(position);
            tv_number.setText("心愿"+info.getTitle()+"已打卡"+info.getTimes()+"次，"+"总进度"+(100*info.getTimes()/info.getTimesall())+"%");

            return view;

        }

    }
}